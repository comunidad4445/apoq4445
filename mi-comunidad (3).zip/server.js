const express = require('express');
const app = express();
const authRoutes = require('./server/auth');
const apiRoutes = require('./server/api');
app.use(express.json());
app.use('/auth', authRoutes);
app.use('/api', apiRoutes);
app.use(express.static(__dirname)); // serve frontend
app.listen(3000, () => console.log('Servidor corriendo en http://localhost:3000'));