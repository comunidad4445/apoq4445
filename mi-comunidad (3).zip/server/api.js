const express = require('express');
const db = require('./db');
const router = express.Router();
router.get('/facturas', (req, res) => {
  db.all('SELECT * FROM facturas', [], (err, rows) => {
    res.json(rows);
  });
});
router.post('/facturas', (req, res) => {
  const { unidad, detalle, monto, fecha } = req.body;
  db.run('INSERT INTO facturas (unidad, detalle, monto, fecha) VALUES (?, ?, ?, ?)', 
    [unidad, detalle, monto, fecha], function(err) {
      res.json({ success: !err, id: this.lastID });
  });
});
module.exports = router;